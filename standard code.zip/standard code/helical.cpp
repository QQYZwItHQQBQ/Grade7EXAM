#include<bits/stdc++.h>
using namespace std;
const int MAXN=1005;
int N,s1,s2,x,y,cnt,a[MAXN][MAXN];
int main(){
	freopen("helical.in","r",stdin);
	freopen("helical.out","w",stdout);
	scanf("%d",&N),s1=N,s2=N/2;
	cnt=a[x=1][y=1]=1;
	while (cnt<=N*N/2-1){
		while (y+1<=N&&(!a[x][y+1])) a[x][++y]=++cnt;
		while (x+1<=N/2&&(!a[x+1][y])) a[++x][y]=++cnt;
		while (y-1>=1&&(!a[x][y-1])) a[x][--y]=++cnt;
		while (x-1>=1&&(!a[x-1][y])) a[--x][y]=++cnt;
	}
	for (int i=N;i>=N/2+1;i--)
		for (int j=1;j<=N;j++)
			a[i][j]=a[N-i+1][j];
	for (int i=1;i<=N;i++){
		for (int j=1;j<=N;j++) printf("%d ",a[i][j]);
		cout<<endl;
	}
	return 0;
}
