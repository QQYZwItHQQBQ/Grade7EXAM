#include<bits/stdc++.h>
using namespace std;
const int MAXN=100005;
int N,M,tmp,ans1,ans2,a[MAXN],b[MAXN];
int main(){
	freopen("defend.in","r",stdin);
	freopen("defend.out","w",stdout);
	scanf("%d%d",&N,&M);
	for (int i=1;i<=N;i++) scanf("%d",&a[i]);
	for (int i=1;i<=M;i++) scanf("%d",&b[i]);
	for (int i=1;i<=N;i++){
		if (i==1) tmp=ans1=1;
		else if (a[i]>a[i-1]) tmp++;
		else ans1=max(ans1,tmp),tmp=1;
	}
	for (int i=1;i<=M;i++){
		if (i==1) tmp=ans2=1;
		else if (b[i]<b[i-1]) tmp++;
		else ans2=max(ans2,tmp),tmp=1;
	}
	cout<<ans1<<" "<<ans2;
	return 0;
}
