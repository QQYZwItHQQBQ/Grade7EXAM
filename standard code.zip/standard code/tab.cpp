#include<bits/stdc++.h>
using namespace std;
const int MAXN=2005;
const int MAXL=5005;
int N,M,K,R,cnt,ans,pos,maxl,num[MAXN],l[MAXN];
bool vis[MAXN];
char ch;
char S[MAXN][MAXL],T[MAXN][MAXL];
map<string,bool> mp;
int main(){
	freopen("tab.in","r",stdin);
	freopen("tab.out","w",stdout);
	scanf("%d%d%d%d %c\n",&N,&M,&K,&R,&ch);
	for (int i=1;i<=N;i++)
		scanf("%s",S[i]),mp[S[i]]=true;
	for (int i=1;i<=M;i++){
		scanf("%s",T[i]),l[i]=strlen(T[i]);
		if (mp.count(T[i])) vis[i]=true;
		for (int j=0;j<l[i];j++)
			if (T[i][j]==ch) num[i]++;
	}
	for (int i=1;i<=M-K+1;i++){
		cnt=maxl=0,pos=-1;
		for (int j=i;j<=i+K-1;j++)
			if (vis[j]) cnt++;
		if (cnt>=R){
			for (int j=i;j<=i+K-1;j++)
				maxl=max(maxl,l[j]);
			for (int j=i;j<=i+K-1;j++)
				if (l[j]==maxl){
					pos=j;
					break;
				}
			ans+=num[pos];
		}
	}
	cout<<ans;
	return 0;
}
