#include<bits/stdc++.h>
using namespace std;
const int MAXN=5005;
int N,M,L,R,cnt,res,k[MAXN],l[MAXN];
bool vis[MAXN];
char ch; 
int main(){
	freopen("vegetarian.in","r",stdin);
	freopen("vegetarian.out","w",stdout);
	scanf("%d%d",&N,&M),cnt=N;
	for (int i=1;i<=N;i++) scanf("%d",&k[i]);
	for (int i=1;i<=M;i++) scanf("%d",&l[i]);
	for (int i=1;i<=M;i++){
		scanf("\n%c",&ch);
		if (ch=='G'||ch=='Q'){
			scanf(" %d %d",&L,&R);
			L=max(1,L),R=min(cnt,R);
		}
		if (ch=='G'){
			if (l[i]==1){
				for (int j=L;j<=R;j++)
					if (k[j]==1) vis[j]=true;
			}
			else
				for (int j=L;j<=R;j++) vis[j]=true;
		}
		else if (ch=='A') k[++cnt]=l[i];
		else{
			res=0;
			for (int j=L;j<=R;j++)
				if (!vis[j]&&k[j]==l[i]) res++;
			printf("%d\n",res);
		}
	}
	return 0;
}
