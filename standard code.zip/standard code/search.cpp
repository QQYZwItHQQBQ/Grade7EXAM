#include<bits/stdc++.h>
using namespace std;
int N,ans1,ans2,ans3;
string S,T,L;
char ch;
int main(){
	freopen("search.in","r",stdin);
	freopen("search.out","w",stdout);
	getline(cin,S),N=S.length();
	ch=getchar(),scanf("\n");
	getline(cin,T);
	getline(cin,L);
	for (int i=0;i<N;i++)
		if (S[i]==ch) ans1++;
	for (int i=0;i<N-1;i++)
		if (S[i]==T[0]&&S[i+1]==T[1]){
			ans2=i+1;
			break;
		}
	for (int i=N-3;i>=0;i--)
		if (S[i]==L[0]&&S[i+1]==L[1]&&S[i+2]==L[2]){
			ans3=i+1;
			break;
		}
	cout<<ans1<<" ";
	if (!ans2) ans2=3334;
	if (!ans3) ans3=3334;
	cout<<ans2<<" "<<ans3;
	return 0;
}
