#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const LL MOD=998244353LL;
LL L,R,k,ans;
bool flg;
int main(){
	freopen("beggar.in","r",stdin);
	freopen("beggar.out","w",stdout);
	scanf("%lld%lld%lld",&L,&R,&k);
	for (LL i=L;i<=R;i++){
		if (i==67||i==251||i==2017||i==2423) continue;
		if (ans%k==0&&ans) continue;
		if (i%10LL==6) continue;
		ans=(ans+i*i)%MOD,flg=true;
	}
	if (flg) cout<<ans;
	else printf("Beautiful BYY");
	return 0;
}
