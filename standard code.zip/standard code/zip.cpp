#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int MAXN=4005;
const LL MOD=998244353;
char buf[1<<25],*p1=buf,*p2=buf;
#define get() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
int N,M,k,ax,ay,bx,by,col[MAXN][MAXN];
LL s[MAXN][MAXN],tmp,ans;
inline int read(){
	register int x=0;
	register char ch=get();
	while (ch<'0'||ch>'9') ch=get();
	while (ch>='0'&&ch<='9')
		x=(x<<1)+(x<<3)+(ch&15),ch=get();
	return x;
}
int gcd(int a,int b){
	return !b?a:gcd(b,a%b);
}
int main(){
	freopen("zip.in","r",stdin);
	freopen("zip.out","w",stdout);
	N=read(),M=read();
	for (int i=1;i<=N;i++)
		for (int j=1;j<=M;j++) col[i][j]=read();
	for (int i=1;i<=N;i++)
		for (int j=1;j<=M;j++)
			s[i][j]=(s[i][j-1]+(LL)col[i][j])%MOD;
	for (int i=1;i<=N;i++)
		for (int j=1;j<=M;j++)
			s[i][j]=(s[i-1][j]+s[i][j])%MOD;
	N--,M--,k=gcd(N,M);
	if (k==1) printf("Beautiful BYY");
	else{
		for (int i=1;i<=k-1;i++){
			ax=i*N/k,ay=i*M/k;
			bx=(k-i)*N/k+1,by=(k-i)*M/k+1;
			if (ax>=bx&&ay>=by) break;
			tmp=(s[bx][by]-s[ax][by]-s[bx][ay]+s[ax][ay]+MOD)%MOD;
			ans=(ans+tmp)%MOD;
		}
		printf("%lld",ans);
	}
	return 0;
}
