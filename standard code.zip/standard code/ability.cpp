#include<bits/stdc++.h>
using namespace std;
int x,cnt;
int main(){
	freopen("ability.in","r",stdin);
	freopen("ability.out","w",stdout);
	scanf("%d",&x);
	if (x%3==0) cout<<"1 ",cnt++;
	if (x%3>0&&x%4==1) cout<<"2 ",cnt++;
	if (x%3>0&&x%5==2) cout<<"3 ",cnt++;
	if (x%28==0&&3334%x>0) cout<<"4 ",cnt++;
	if ((x%10==1||x%10==3||x%10==4)&&x%6==0)
		cout<<"5 ",cnt++;
	if (!cnt) printf("Beautiful BYY");
	return 0; 
} 
